
import requests, urllib, json
from time import sleep
import pandas as pd
from datetime import datetime
from dateutil.relativedelta import relativedelta

#%%
# To fill missing day

def complete_missing_days(df, min_date="2008-01-01", max_date="2023-12-31"):
    
    df['fecha'] = pd.to_datetime(df['fecha'], format='%Y-%m-%d')  # Ensure date format is correct
    df.set_index('fecha', inplace=True)  # Set 'fecha' as the index for interpolation
    
    # Ensure there is a row for every day in the range from min to max date
    all_dates = pd.date_range(start=min_date, end=max_date, freq='D')
    df = df.reindex(all_dates)
    
    # Interpolate numeric columns
    numeric_cols = df.select_dtypes(include=['number']).columns
    df[numeric_cols] = df[numeric_cols].interpolate(method='time')
    
    # Fill categorical columns using forward fill, then backward fill to cover leading missing values
    categorical_cols = df.select_dtypes(include=['object']).columns
    df[categorical_cols] = df[categorical_cols].fillna(method='ffill').fillna(method='bfill')
    
    # Reset the index to add 'fecha' back as a column
    df.reset_index(inplace=True)
    df.rename(columns={'index': 'fecha'}, inplace=True)

    return df

#%%
# To download weather station data from AEMET

def fetch_weather_data(fechaini, fechafin, estacion):
    
    api_key = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJqdWFubWFydGluQHVzYWwuZXMiLCJqdGkiOiJmZWJhZGYzZS04ZWNmLTRmODQtOWM1Ny00YzA4ZGE5OWQ1ODAiLCJpc3MiOiJBRU1FVCIsImlhdCI6MTcxNTI1NTY0NywidXNlcklkIjoiZmViYWRmM2UtOGVjZi00Zjg0LTljNTctNGMwOGRhOTlkNTgwIiwicm9sZSI6IiJ9.IHpbfLtt-xBe-3xakdK66elzbH8ADyGIPyxgQoiHwjo"

    # Convert string dates to datetime objects
    start_date = datetime.strptime(fechaini, "%Y-%m-%d")
    end_date = datetime.strptime(fechafin, "%Y-%m-%d")
    
    # Initialize the final DataFrame
    df_final = pd.DataFrame()

    # Process in 4-year intervals
    while start_date < end_date:
        print(start_date)
        # Add four years to the start date but subtract a day to end on December 31st
        interval_end = min(start_date + relativedelta(months=6, days=-1), end_date)

        # Format dates for the API
        start_str = start_date.strftime("%Y-%m-%d") + "T00:00:00UTC"
        end_str = interval_end.strftime("%Y-%m-%d") + "T23:59:59UTC"
        
        # Build the request URL
        url = f"https://opendata.aemet.es/opendata/api/valores/climatologicos/diarios/datos/fechaini/{start_str}/fechafin/{end_str}/estacion/{estacion}/?api_key={api_key}"
        headers = {
            'cache-control': "no-cache"
        }

        # Request the API
        response = requests.request("GET", url, headers=headers).json()
        
        # Check if the request was successful
        if response["estado"] == 200:
            url_datos = response["datos"]
            
            # Fetch and read the data
            with urllib.request.urlopen(url_datos) as resp:
                sleep(3)  # Sleep to prevent hitting rate limits
                df_json = resp.read()
                
            try:
                data = json.loads(df_json)
            except UnicodeDecodeError:
                data_bytes = df_json.decode('iso-8859-1')
                data = json.loads(data_bytes)
            
            # Convert to DataFrame
            df = pd.DataFrame(data)
            df = df.reset_index(drop=True)
            atts = ['fecha', 'indicativo', 'nombre', 'provincia', 'altitud', 'tmed', 'tmin', 'tmax']
            
            if not all(col in df.columns for col in atts):
                start_date = interval_end + relativedelta(days=1)
                continue
            
            data = df[atts].copy()  # Hacemos una copia explícita para evitar el warning

            # Replace commas in the temperature fields and convert to float
            columns_to_replace = ['tmed', 'tmin', 'tmax']
            for columna in columns_to_replace:
                data[columna] = data[columna].str.replace(",", ".").astype(float)

            # Concatenate to the final DataFrame
            df_final = pd.concat([df_final, data], ignore_index=True)

        # Move to the start of the next 4-year period
        start_date = interval_end + relativedelta(days=1)

    return df_final
