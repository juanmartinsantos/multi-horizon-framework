
import os
import pandas as pd

user = os.getlogin()
path = f"C:/Users/{user}/OneDrive/Doctorado/temp_TS/Nueva_revision/DesacargaDatasetNuevos/01.data/"

#%%
# Leer el archivo CSV con codificación UTF-8
df_csv_corrected = pd.read_csv(path + 'listado_estaciones.csv', delimiter=';', encoding='utf-8')

# Filtrar las provincias para excluir ciertas regiones
filtered_df = df_csv_corrected[~df_csv_corrected['provincia'].isin([
    'STA. CRUZ DE TENERIFE', 'LAS PALMAS', 'ILLES BALEARS', 'CEUTA', 
    'MELILLA', 'BALEARES', 'ARABA/ALAVA'])]

# filtered_df.to_csv(path + 'todaslasestaciones.csv', index=False, sep=";", encoding='utf-8')

# Ver la cantidad de estaciones por provincia después de filtrar
filtered_provincia_counts = filtered_df['provincia'].value_counts()

# Calcular el número de estaciones a seleccionar por provincia
num_stations_per_province = 100 // len(filtered_provincia_counts)

# Seleccionar estaciones equitativamente
filtered_selected_stations_list = []

for provincia in filtered_provincia_counts.index:
    num_stations = min(num_stations_per_province, filtered_provincia_counts[provincia])
    selected_stations = filtered_df[filtered_df['provincia'] == provincia].sample(num_stations, random_state=1)
    filtered_selected_stations_list.append(selected_stations)

# Concatenar todas las estaciones seleccionadas
filtered_selected_stations_df = pd.concat(filtered_selected_stations_list)

# Si faltan estaciones para completar 100, seleccionar aleatoriamente del resto
if len(filtered_selected_stations_df) < 100:
    remaining_stations = filtered_df[~filtered_df.index.isin(filtered_selected_stations_df.index)].sample(100 - len(filtered_selected_stations_df), random_state=1)
    filtered_selected_stations_df = pd.concat([filtered_selected_stations_df, remaining_stations])

# Guardar el DataFrame en un archivo CSV para su descarga con codificación UTF-8
output_csv_path = path + 'Estaciones_Seleccionadas.csv'
filtered_selected_stations_df.to_csv(output_csv_path, index=False, sep=";", encoding='utf-8')

print(f"Archivo guardado en: {output_csv_path}")
