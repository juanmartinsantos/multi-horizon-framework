# library(scmamp) # para friedmanAlignedRanksPost // wilcox.test

AlignedFriedman <- function(data){
  
  test_res <- list()
  
  # compute ranks ######################################################
  N <- dim(data)[1]
  k <- dim(data)[2]
  dataset.means <- rowMeans(data)
  diff.matrix <- data - matrix(rep(dataset.means, k), ncol=k)
  ranks <- matrix(rank(-unlist(diff.matrix)), ncol=k, byrow=FALSE)
  colnames(ranks) <- colnames(data)
  rj <- colSums(ranks)/N
  test_res$ranks <- rj
  
  # compute pAF ######################################################
  test_res$pAF <- friedmanAlignedRanksTest(data)$p.value
  
  # compute raw pvalues AF ###########################################
  control <- which.min(rj)
  raw <- friedmanAlignedRanksPost(data = data, control = control)
  
  # compute post hoc test: Finner ####################################
  test_res$pFin <- adjustFinner(raw)[1,]

  return(test_res)
}

Wilcoxon_NoRanks <- function(x, y){
  
  w <- wilcox.test(x = x, y = y, alternative = "two.sided", paired = TRUE)
  res <- list(statistic = w$statistic, pvalue = w$p.value)
  
  return(res)
}

Wilcoxon <- function(x, y, maximize = TRUE){
  
  diff <- c(x - y) # differences
  diff <- diff[diff != 0] # delete differences = 0
  
  diff_rank <- rank(abs(diff)) # ranks (lower difference -> lower rank)
  diff_rank_sign <- diff_rank * sign(diff)
  
  ranks_pos <- sum(diff_rank_sign[diff_rank_sign > 0])
  ranks_neg <- -sum(diff_rank_sign[diff_rank_sign < 0])
  
  w <- wilcox.test(x = x, y = y, alternative = "two.sided", paired = TRUE)
  
  if(maximize)
    res <- list(rank_pos = ranks_pos, rank_neg = ranks_neg, pvalue = w$p.value)
  else
    res <- list(rank_pos = ranks_neg, rank_neg = ranks_pos, pvalue = w$p.value)
  
  return(res)
}
