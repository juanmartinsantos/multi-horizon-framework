###############################################################################
###############################################################################
###############################################################################
path <- "C:/Users/JuanMiguelMartinSant/OneDrive/Doctorado/temp_TS/Nueva_revision/Temp_TS_JM/"

# Load library
source(paste0(path, "02.code/project_library.R"))
# setwd("~/research/software/Rcode/24_ts/")

# Load other scripts
scripts <- c('00_functions.R','01_regression.R','partitioning.R','evaluate.R','prepareData.R')
files <- list.files(path = paste0(path,"/02.code/"), pattern = "[.]R$", recursive = TRUE)
files <- files[files%in%scripts]
lapply(paste0(path,"02.code/", files), source)

###############################################################################
# -------------------------- Ajusta Las varibales --------------------------- #
###############################################################################
# file <- paste0(path, "01.data/raw/joined.csv")
file <- paste0(path, "01.data/raw/alm_ori.csv")
data <- read.table(file = file, header = T, sep = ";", dec = ".")

# vars <- c("Date","TEMPERATURE_MIN","TEMPERATURE_MAX", "TEMPERATURE")
vars <- c("FECHA","Al02TMin","Al02TMax","Al02TMed")
data <- data[,vars]
colnames(data) <- c("date", "tmin", "tmax", "t")
# data$date <- as.Date(x = as.character(data$date), format = "%d/%m/%Y")
data$date <- as.Date(x = as.character(data$date), format = "%d/%m/%y")
data <- data[data$date>"2000-12-31",]
data <- data[order(data$date),]

# Transforma numerico
data[,c("tmin","tmax","t")] <- apply(data[,c("tmin","tmax","t")], 2, FUN = function(x){as.numeric(as.character(x))})
data <- data[complete.cases(data),]

###############################################################################
# ------------------------- Ajusta fechas faltantes ------------------------- #
###############################################################################
data$month <- month(data$date)
data$day <- day(data$date)
data$year <- year(data$date)
data$yearday <- yday(data$date)

dt_i <- as.Date(x = "01/01/2001", format = "%d/%m/%Y")
dt_f <- as.Date(x = "31/12/2021", format = "%d/%m/%Y")
range <- seq(dt_i, dt_f, by = 1)

faltantes <- range[!range %in% data$date] 

dataf <- NULL
for(i in 1:length(faltantes)){
  # i = 1
  date.aux <- faltantes[i]
  idx_cd <- order(abs(as.numeric(data$date - date.aux)))[1:2]
  cd <- data[idx_cd,]
  sel <- cd[1,]
  sel$t <- mean(cd$t)
  sel$tmin <- mean(cd$tmin)
  sel$tmax <- mean(cd$tmax)
  sel$date <- date.aux
  sel$yearday <- yday(date.aux)
  sel$month <- month(date.aux)
  sel$day <- day(date.aux)
  sel$year <- year(date.aux)
  dataf <- rbind(dataf, sel)
}

data <- rbind.fill(data, dataf)
data <- data[order(data$date),]
data <- data[,c('date','tmin','tmax','month','day','year','yearday','t')]
colnames(data)[ncol(data)] <- "output"

write.table(x = data, file = paste0(path, "01.data/alm0121.csv"), quote = F, sep = ";", row.names = F, col.names = T)

#############
#############
rm(list = ls())
