
import pandas as pd
import os
import unidecode

user = os.getlogin()
path = "C:/Users/{user}/OneDrive/Doctorado/temp_TS/Nueva_revision/"
path_in = path + "DesacargaDatasetNuevos/01.data/WeatherData/"
path_out = path + "Temp_TS_JM/01.data/newdata/"

#%%

files = os.listdir(path_in)

for file in files:

    data = pd.read_csv(path_in + file, sep=";", encoding='ISO-8859-1')
    
    # Parse the date and extract the required fields
    data['fecha'] = pd.to_datetime(data['fecha'], format='%Y-%m-%d')
    data['month'] = data['fecha'].dt.month
    data['day'] = data['fecha'].dt.day
    data['year'] = data['fecha'].dt.year
    data['yearday'] = data['fecha'].dt.dayofyear
    data['output'] = data['tmed']
    
    # Selecting and renaming the columns as required
    df = data[['fecha', 'tmin', 'tmax', 'month', 'day', 'year', 'yearday', 'output']]
    df = df.rename(columns={'fecha': 'date'})
    
    name = unidecode.unidecode(file.replace(',', '').replace(' ', '_'))
    
    df.to_csv(path_out + name, sep =";", index=False)


