
import os
from tqdm import tqdm
import pandas as pd
from FUNCTIONS import fetch_weather_data

#%%
user = os.getlogin()
path = f"C:/Users/{user}/OneDrive/Doctorado/temp_TS/Nueva_revision/DesacargaDatasetNuevos/01.data/"
# estaciones = pd.read_csv(path + 'Estaciones_Seleccionadas.csv', sep = ";")
estaciones = pd.read_csv(path + 'listado_estaciones.csv', sep = ";")
estaciones = estaciones[estaciones["provincia"] == 'ALMERIA'] # Filtra por provincia
estaciones = estaciones["indicativo"]

# path_save = path + "RawWeatherData/"
path_save = f"C:/Users/{user}/OneDrive/Doctorado/temp_TS/Nueva_revision/Temp_TS_JM_V2/01.data/raw/" # Apunta a V2
# Example usage:
fechaini = "2008-01-01"
fechafin = "2023-12-31"
# estaciones = ['5270B', '7227X', '8178D', '3469A', '1249I', '6325O', '9381I', 
#               '2117D', '2867', '9434', '1505', '3013', '4642E', '9263D', 
#               '8416', '3260B', '1387', '9771C', '4478X', '5783']

codes_empty = []
all_dates = []
# Get data
for e in tqdm(estaciones[11:]):
    df_weather = fetch_weather_data(fechaini, fechafin, estacion = e)
    if len(df_weather) == 0:
        codes_empty.append(e)
        continue 
    nm = df_weather["nombre"].unique()[0].replace("'", "")
    all_dates.append(df_weather)
    nm = pd.Series(nm).str.replace('/', '', regex=False)[0]
    df_weather.to_csv(path_save + f"{nm}.csv", sep=";", index=False)
    

# df_weather = fetch_weather_data(fechaini, fechafin, estacion = '0229I')
#%%
import pickle

# Ruta del archivo donde se guardará la lista
ruta_archivo = path_save + "lista_all_dates.pkl"

# Guardar la lista en un archivo
with open(ruta_archivo, 'wb') as archivo:
    pickle.dump(all_dates, archivo)
