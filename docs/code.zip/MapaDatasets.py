
import os
import geopandas as gpd
import matplotlib.pyplot as plt

# Carga el mapa de España
user = os.getlogin()
mapa_espana = gpd.read_file(f"C:/Users/{user}/OneDrive/Doctorado/temp_TS/Nueva_revision/DesacargaDatasetNuevos/01.data/spain-provinces.geojson")

# Plotea el mapa
fig, ax = plt.subplots(1, 1, figsize=(8, 12))
mapa_espana.plot(ax=ax)

# Lista de ciudades y sus coordenadas
ciudades = {
    'Almería': (-2.4640, 36.8400),
    'Huelva': (-6.9500, 37.2667),
    'Valencia': (-0.3750, 39.4667),
    'Murcia': (-1.1300, 37.9833),
    'Lleida': (0.6252, 41.6176),
    'Sevilla': (-5.9845, 37.3891),
    'Toledo': (-4.0226, 39.8628),
    'Valladolid': (-4.7237, 41.6523),
    'Logroño': (-2.4455, 42.4667),
    'Zaragoza': (-0.8877, 41.6488),
    'Badajoz': (-6.9706, 38.8803),
    'Salamanca': (-5.6639, 40.9688),
    'Marmolejo': (-4.1667, 38.0500),  # Estas son coordenadas aproximadas
    'Cáceres': (-6.3708, 39.4753),
    'Lugo': (-7.50161513, 42.50692206),
    'Boimorto': (-8.1500, 43.1167),  # Estas son coordenadas aproximadas
    'Pamplona': (-1.6462, 42.8169),
    'Prados Redondos': (-2.7600, 40.6333),  # Estas son coordenadas aproximadas
    'Tarragona': (1.2585, 41.1172),
    'Albacete': (-1.8558, 38.9942)
}

# Añade puntos rojos para cada ciudad
for nombre, (lon, lat) in ciudades.items():
    ax.scatter(lon, lat, color='red', s=50)  # s es el tamaño del punto

# Establece los límites para enfocar solo la península
ax.set_xlim(-10, 5)  # Ajusta según necesidad para limitar la vista a la península
ax.set_ylim(35, 44)  # Ajusta según necesidad para limitar la vista a la península

# Añade títulos y otros elementos de estilo
ax.set_title('Mapa de la Península Ibérica con Ciudades Importantes')
ax.set_xlabel('Longitud')
ax.set_ylabel('Latitud')

plt.show()


#%%
