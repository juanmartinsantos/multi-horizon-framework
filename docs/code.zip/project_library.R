library(ggplot2)
library(gridExtra)
library(egg)
library(dplyr)
library(timetk)
library(modelr)
library(hydroGOF)
library(MLmetrics)
library(lubridate)
library(xgboost)
library(caret)
library(psych)
library(plyr)
library(scmamp) # devtools::install_github("b0rxa/scmamp")

send_telegram <- function(message='Finish'){
  library(reticulate)
  use_python("C:/Users/juanm/anaconda3/envs/telegram-env/python.exe", required = T)
  
  py.lib <- import("telegram_send")
  py.lib$send(messages= list(message))
}
