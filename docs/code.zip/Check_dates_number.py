
import pandas as pd
import os
from FUNCTIONS import complete_missing_days
# from datetime import datetime, timedelta

user = os.getlogin()
# path = f"C:/Users/{user}/OneDrive/Doctorado/temp_TS/Nueva_revision/DesacargaDatasetNuevos/01.data/RawWeatherData/"
path = f"C:/Users/{user}/OneDrive/Doctorado/temp_TS/Nueva_revision/Temp_TS_JM_V2/01.data/raw/"

#%%
results = []
for filename in os.listdir(path):
    if filename.endswith(".csv"):  # Assuming files are in CSV format
        filepath = os.path.join(path, filename)
        df = pd.read_csv(filepath, sep=';')  # Adjust delimiter if necessary
        df['fecha'] = pd.to_datetime(df['fecha'], format='%Y-%m-%d')  # Adjust date format as necessary

        # min_date = df['fecha'].min()
        # max_date = df['fecha'].max()
        min_date = pd.to_datetime('2008-01-01', format='%Y-%m-%d')
        max_date = pd.to_datetime('2023-12-31', format='%Y-%m-%d')
        all_dates = pd.date_range(start=min_date, end=max_date, freq='D')
        missing_dates = all_dates.difference(df['fecha'])
        missing_count = len(missing_dates)

        results.append({
            'provincia': df["provincia"].unique()[0].replace("'", ""),
            'file': filename[:-4],
            'min_date': min_date,
            'max_date': max_date,
            'missing_days_total': missing_count
            # 'missing_days': missing_dates,
            # 'missing': (missing_count/5844)*100
        })

## To cacth the files with "threshold" greater than X
filtered_results = [result for result in results if result['missing_days_total'] < 30]
    
complete_missing_days(df, min_date="2008-01-01", max_date="2023-12-31")

#%%
path_save = f"C:/Users/{user}/OneDrive/Doctorado/temp_TS/Nueva_revision/DesacargaDatasetNuevos/01.data/WeatherData/"

for filename in os.listdir(path):
    # filename = os.listdir(path)[0]
        if filename.endswith(".csv"):
            filepath = os.path.join(path, filename)
            df = pd.read_csv(filepath, sep=';')  # Adjust delimiter if necessary
            if len(df) == 5844:
                df.to_csv(path_save + f"{filename}", sep=";", index=False, encoding='ISO-8859-1')
            else:
                df_save = complete_missing_days(df)
                df_save.to_csv(path_save + f"{filename}", sep=";", index=False, encoding='ISO-8859-1')











