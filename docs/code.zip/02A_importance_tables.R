###############################################################################
###############################################################################
###############################################################################
user <- Sys.getenv("USERNAME")
path <- paste0("C:/Users/",user,"/OneDrive/Doctorado/temp_TS/Nueva_revision/Temp_TS_JM/")

# Load library
source(paste0(path, "02.code/project_library.R"))
# setwd("~/research/software/Rcode/24_ts/")

# Load other scripts
scripts <- c('00_functions.R','01_regression.R','partitioning.R','evaluate.R','prepareData.R')
files <- list.files(path = paste0(path,"/02.code/"), pattern = "[.]R$", recursive = TRUE)
files <- files[files%in%scripts]
lapply(paste0(path,"02.code/", files), source)

###############################################################################
# --------------------- Crea tablas GAIN - COVER - FREQ --------------------- #
###############################################################################
files <- list.files(paste0(path, "01.data/newdata/"))
max_horizon <- 31
max_days <- 31

for(file in files){
  print(file)
  data <- read.table(file = paste0(path, "01.data/newdata/", file), header = T, sep = ";")
  data$date <- as.Date(x = as.character(data$date), format = "%Y-%m-%d")
  data$t <- data$output
  data <- data[,c("t", "tmin", "tmax", "date", "yearday", "month", "day", "year","output")]
  
  ###############
  # Crea tablas #
  ###############
  TABLE_GAIN <- NULL
  TABLE_COVER <- NULL
  TABLE_FREQ <- NULL
  
  file_hist <- paste0(path, "01.data/dh5_newdata/dh5_",file)
  his_data <- read.table(file = file_hist, header = T, sep = ";")
  
  for(i in 1:max_horizon){
    # i = 1
    print(paste0(i, "/", max_horizon))
    
    act_data <- ACTUALdata(data, i, max_days)
    out <- data$output
    act_data$output <- NULL
    his_data$output <- NULL
    ts_data <- cbind(act_data, his_data, out)
    ts_data <- ts_data[complete.cases(ts_data),]
    
    ######################################################################
    
    if(is.null(TABLE_GAIN)){
      TABLE_GAIN <- data.frame(Feature = colnames(ts_data)[-ncol(ts_data)])
      TABLE_COVER <- data.frame(Feature = colnames(ts_data)[-ncol(ts_data)])
      TABLE_FREQ <- data.frame(Feature = colnames(ts_data)[-ncol(ts_data)])
    }
    
    ######################################################################
    
    #define predictor and response variables in training set
    train_x <- data.matrix(ts_data[,-ncol(ts_data)])
    train_y <- ts_data[,ncol(ts_data)]
    xgb_train <- xgb.DMatrix(data = train_x, label = train_y)
    
    #define final model
    model_xgboost <- xgboost(data = xgb_train, nrounds = 1000, verbose = 0, params = list(max_depth = 10, eta = 0.1))
    
    # Compute feature importance matrix
    importance_matrix <- xgb.importance(feature_names = colnames(xgb_train), model = model_xgboost)
    
    ######################################################################
    
    idxord <- match(x = TABLE_GAIN$Feature, table = importance_matrix$Feature)
    TABLE_GAIN <- cbind(TABLE_GAIN, importance_matrix[idxord,c("Gain")])
    TABLE_COVER <- cbind(TABLE_COVER, importance_matrix[idxord,c("Cover")])
    TABLE_FREQ <- cbind(TABLE_FREQ, importance_matrix[idxord,c("Frequency")])
    
    names(TABLE_GAIN)[ncol(TABLE_GAIN)] <- paste0("Gain_",i)
    names(TABLE_COVER)[ncol(TABLE_COVER)] <- paste0("Cover_",i)
    names(TABLE_FREQ)[ncol(TABLE_FREQ)] <- paste0("Freq_",i)
  }
  
  write.table(x = TABLE_GAIN, file = paste0(path, "04.results/Gain/gain5_",file), quote = F, sep = ";", row.names = F, col.names = T)
  write.table(x = TABLE_COVER, file = paste0(path, "04.results/Cover/cover5_",file), quote = F, sep = ";", row.names = F, col.names = T)
  write.table(x = TABLE_FREQ, file = paste0(path, "04.results/Freq/freq5_",file), quote = F, sep = ";", row.names = F, col.names = T)
  
}

###############################################################################
# ------------------------------ CREA GRAFICOS ------------------------------ #
###############################################################################
cdad <- "pon" # alm, pon
TABLE_GAIN <- read.table(file = paste0(path, "04.results/",cdad,"_gain5.csv"), sep = ";", header = T)
res <- TABLE_GAIN
res[is.na(res)] <- 0
rownames(res) <- res[,1]
res$Feature <- NULL
res <- t(res)

nm <- c()
for(c in 1:nrow(res)){
  nm <- c(nm, colnames(res)[order(res[c,], decreasing = T)[1:5]])
}
nm <- unique(nm)
res2 <- res[,nm]


library(ggplot2)
data_ggp <- data.frame(x = 1:max_horizon, y = as.vector(res2), group = rep(colnames(res2), each = max_horizon))

ggp <- ggplot(data_ggp, aes(x, y, col = group)) +
  geom_line()
ggp  
