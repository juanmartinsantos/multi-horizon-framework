####################################################################################
####################################################################################
####################################################################################
ACTUALdata <- function(data_, before_, days_){
  # data_ = data
  # before_ = 1
  # days_ = 31
  data_out <- data_[,ncol(data_), drop = FALSE]
  kmin_ <- before_
  kmax_ <- (kmin_+days_)-1
  
  for(i in 1:3){
    # i = 1
    for(k1 in kmin_:kmax_){
      # k1 = kmin_
      aux_ <- c()
      for(k2 in kmin_:k1){
        # k2 <- 2
        aux_ <- cbind(aux_,lag(data_[,i],k2))
      }
      
      newcol <- apply(X = aux_, MARGIN = 1, mean)
      data_out <- cbind(data_out,newcol)
      colnames(data_out)[ncol(data_out)] <- paste0(colnames(data_)[i], "_", (k1-kmin_+1))
    }
  }
  
  data_out <- cbind(data_out, data_[,5:8])
  
  return(data_out)
}

####################################################################################
####################################################################################
####################################################################################

HISTdata <- function(data_, nyb_){
  # data_ <- data
  # nyb_ <- 5
  
  data_out <- data_[,ncol(data_), drop = FALSE]
  txtday <- c(1,3,7,15,31)
  dba <- c(0,1,3,7,15)
  
  for(y in 1:nyb_){
    # y = 1
    for(d in 1:length(dba)){
      # d = 1
      print(paste(y,d))
      
      resy <- matrix(data = NA, nrow = nrow(data_), ncol = 3)
      colnames(resy) <- paste0(colnames(data_)[1:3], "_y", y, "d", txtday[d])
      
      for(i in 1:nrow(data_)){
        # i = 1
        curdate <- data_[i,]$date
        if(day(curdate) == 29 && month(curdate) == 2){ # Feb 29
          day(curdate) <- 28
        }
        
        idx <- c()
        for(oy in 1:y){
          # oy = 1
          auxdate <- curdate
          year(auxdate) <- year(auxdate)-oy
          
          di <- auxdate-dba[d]
          df <- auxdate+dba[d]
          
          idx <- c(idx, which(data_$date >= di & data_$date <= df))
        }
        
        new <- data_[idx,-ncol(data_)]
        new <- new[1:(y*(dba[d]*2+1)),1:3]
        yaux <- apply(X = new, MARGIN = 2, FUN = mean)
        resy[i,] <- yaux
      }
      
      data_out <- cbind(data_out, resy)
    }
  }
  
  return(data_out)
}

###############################################################
###############################################################
###############################################################

normalizeRegData <- function(data_){
  
  pdata <- apply(data_, MARGIN = 2,
                 FUN = function(x){
                   resx <- (x - min(x)) / (max(x) - min(x))
                   return(resx)
                 })
  
  pdata <- as.data.frame(pdata)
  return(pdata)
}


###############################################################################
###############################################################################
###############################################################################

f1 <- function(){
  
  dpaux <- matrix(data = NA, nrow = 31, ncol = length(uq_type))
  colnames(dpaux) <- uq_type
  for(i in 1:ncol(dpaux)){
    dpaux[,i] <- apply(X = dp_ori[,var_type == uq_type[i]], MARGIN = 1, FUN = mean)
  }
  
  sol_ <- dpaux
  return(sol_)
}

f2 <- function(){
  
  res1 <- matrix(data = NA, nrow = ncol(dp_ori), ncol = 12)
  res1 <- as.data.frame(res1)
  rownames(res1) <- colnames(dp_ori)
  colnames(res1) <- c("mean", "sd", "min", "daymin", "max", "daymax", "w1", "w2", "w3", "w4", "ranks", "pFin")
  af <- AlignedFriedman(dp_ori)
  
  for(v in 1:ncol(dp_ori)){
    res1[v,1] <- formatC(mean(dp_ori[,v]), format = "e", digits = 2)
    res1[v,2] <- formatC(sd(dp_ori[,v]), format = "e", digits = 2)
    res1[v,3] <- formatC(min(dp_ori[,v]), format = "e", digits = 2)
    res1[v,4] <- which(dp_ori[,v] == min(dp_ori[,v]), arr.ind = TRUE)[1]
    res1[v,5] <- formatC(max(dp_ori[,v]), format = "e", digits = 2)
    res1[v,6] <- which(dp_ori[,v] == max(dp_ori[,v]), arr.ind = TRUE)[1]
    
    oau <- t(apply(X = dp_ori, MARGIN = 1, FUN = function(x) {order(x, decreasing = T)}))
    
    rpc <- apply(X =  oau[1:7,], MARGIN = 2, function(x){sum(x == v)})
    res1[v,7] <- paste0(rpc, collapse = "/")
    
    rpc <- apply(X =  oau[8:14,], MARGIN = 2, function(x){sum(x == v)})
    res1[v,8] <- paste0(rpc, collapse = "/")
    
    rpc <- apply(X =  oau[15:21,], MARGIN = 2, function(x){sum(x == v)})
    res1[v,9] <- paste0(rpc, collapse = "/")
    
    rpc <- apply(X =  oau[22:31,], MARGIN = 2, function(x){sum(x == v)})
    res1[v,10] <- paste0(rpc, collapse = "/")
    
    res1[v,11] <- round(af$ranks[v], 2)
    res1[v,12] <- formatC(af$pFin[v], format = "e", digits = 2)
  }
  
  return(res1)
}

###############################################################################
###############################################################################
###############################################################################

AlignedFriedman <- function(data){
  
  test_res <- list()
  
  # compute ranks ######################################################
  N <- dim(data)[1]
  k <- dim(data)[2]
  dataset.means <- rowMeans(data)
  diff.matrix <- data - matrix(rep(dataset.means, k), ncol=k)
  ranks <- matrix(rank(-unlist(diff.matrix)), ncol=k, byrow=FALSE)
  colnames(ranks) <- colnames(data)
  rj <- colSums(ranks)/N
  test_res$ranks <- rj
  
  # compute pAF ######################################################
  test_res$pAF <- friedmanAlignedRanksTest(data)$p.value
  
  # compute raw pvalues AF ###########################################
  control <- which.min(rj)
  raw <- friedmanAlignedRanksPost(data = data, control = control)
  
  # compute post hoc test: Finner ####################################
  test_res$pFin <- adjustFinner(raw)[1,]
  
  return(test_res)
}

Wilcoxon_NoRanks <- function(x, y){
  
  w <- wilcox.test(x = x, y = y, alternative = "two.sided", paired = TRUE)
  res <- list(statistic = w$statistic, pvalue = w$p.value)
  
  return(res)
}

Wilcoxon <- function(x, y, maximize = TRUE){
  
  diff <- c(x - y) # differences
  diff <- diff[diff != 0] # delete differences = 0
  
  diff_rank <- rank(abs(diff)) # ranks (lower difference -> lower rank)
  diff_rank_sign <- diff_rank * sign(diff)
  
  ranks_pos <- sum(diff_rank_sign[diff_rank_sign > 0])
  ranks_neg <- -sum(diff_rank_sign[diff_rank_sign < 0])
  
  w <- wilcox.test(x = x, y = y, alternative = "two.sided", paired = TRUE)
  
  if(maximize)
    res <- list(rank_pos = ranks_pos, rank_neg = ranks_neg, pvalue = w$p.value)
  else
    res <- list(rank_pos = ranks_neg, rank_neg = ranks_pos, pvalue = w$p.value)
  
  return(res)
}
