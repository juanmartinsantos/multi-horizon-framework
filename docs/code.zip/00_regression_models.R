###############################################################################
###############################################################################
###############################################################################
GetPredictions <- function(train_, test_, method_){
  
  if(method_ == "meanreg"){
    
    output <- ncol(train_)
    
    if(ncol(train_) > 2){
      test_ <- test_[,-ncol(test_)]
    }
    else{
      test_ <- test_[,-ncol(test_), drop = F]
    }
    
    pred <- rep(mean(train_[,ncol(train_)]), nrow(test_))
    
    return(pred)
  }
  
  ################################################################################
  else if(method_ == "ELM"){
    
    output <- train_[,ncol(train_)]
    train_ <- train_[,-ncol(train_)]
    test_ <- test_[,-ncol(test_)]
    
    out_mx <- as.matrix(output)
    train_mx <- as.matrix(train_)
    test_mx <- as.matrix(test_)
    
    model <- elm_train(x = train_mx, y = out_mx, nhid = 20, actfun = "radbas")
    pred <- elm_predict(elm_train_object = model, newdata = test_mx)
    
    return(as.numeric(pred))
  }
  
  ################################################################################
  else if(method_ == "XGBoost"){

    target <- train_[,ncol(train_)]
    dtrain <- xgb.DMatrix(data = as.matrix(train_[,-ncol(train_)]), label = target, missing = NA)
    dtest <-  xgb.DMatrix(data = as.matrix(test_[,-ncol(test_)]), missing = NA)

    model <- xgboost(data = dtrain, nrounds = 100, verbose = FALSE)
    pred <- predict(model, dtest)

    return(pred)
  }
  
  ################################################################################
  else if(method_ == "SVM"){

    output <- train_[,ncol(train_)]
    train_ <- train_[,-ncol(train_)]
    test_ <- test_[,-ncol(test_)]

    model <- e1071::svm(x = train_, y = output, scale = TRUE, type = "eps-regression", kernel = "radial")
    pred <- predict(model, test_)
    
    return(pred)
  }
  
  ################################################################################
  else if(method_ == "MARS"){

    output <- train_[,ncol(train_)]
    train_ <- train_[,-ncol(train_)]
    test_ <- test_[,-ncol(test_)]

    model <- earth(x = train_, y = output)
    pred <- predict(model, test_)
    
    return(as.numeric(pred))
  }
  
  ################################################################################
  else if(method_ == "RPART"){

    output <- ncol(train_)
    test_ <- test_[,-ncol(test_)]

    frm <- as.formula(paste(names(train_)[output],"~.",sep = ""))

    model <- rpart::rpart(frm, train_)
    pred <- predict(model, test_, type="vector")

    return(pred)
  }
  
  ################################################################################
  else if(method_ == "1NN"){

    output <- train_[,ncol(train_)]
    train_ <- train_[,-ncol(train_)]
    test_ <- test_[,-ncol(test_)]

    pred <- FNN::knn.reg(train = train_, test = test_, y = output, k = 1, algorithm=c("brute"))$pred
    
    return(pred)
  }
  
  ################################################################################
  else if(method_ == "3NN"){
    
    output <- train_[,ncol(train_)]
    train_ <- train_[,-ncol(train_)]
    test_ <- test_[,-ncol(test_)]
    
    pred <- FNN::knn.reg(train = train_, test = test_, y = output, k = 3, algorithm=c("brute"))$pred
    
    return(pred)
  }
  
  ################################################################################
  else if(method_ == "RF"){
    
    output <- train_[,ncol(train_)]
    train_ <- train_[,-ncol(train_)]
    test_ <- test_[,-ncol(test_)]

    model <- randomForest(train_, y = output,  xtest = NULL, ytest = NULL, ntree = 100)
    pred <- predict(model, test_)
    
    return(pred)
  }
  
  ################################################################################
  else if(method_ == "GBM"){
    
    test_ <- test_[,-ncol(test_)]
    
    frm <- as.formula(paste0(names(train_)[ncol(train_)], "~."))
    
    model <- gbm::gbm(formula = frm, distribution = "gaussian", data = train_, n.trees = 100, bag.fraction = 0.8)
    pred <- predict.gbm(model, test_, n.trees = 100)
    
    return(pred)
  }

  ################################################################################
  else if(method_ == "Lasso"){
    
    output <- train_[,ncol(train_)]
    train_ <- as.matrix(train_[,-ncol(train_)])
    test_ <- as.matrix(test_[,-ncol(test_)])

    model <- cv.glmnet(train_, output, family="gaussian",alpha = 0.111,thresh = 1E-9,
                       nlambda = 100,s=0.0001,lambda.min.ratio = 0.000001, standardize = TRUE)
    pred <- predict(model, test_)
    
    return(as.numeric(pred))
  }
  
  ################################################################################
  else if(method_ == "LR"){
    
    frm <- as.formula(paste0(names(train_)[ncol(train_)], "~."))
    
    output <- train_[,ncol(train_)]
    test_ <- test_[,-ncol(test_)]
    
    model <- lm(frm, train_)
    pred <- predict(model, test_)
    
    return(as.numeric(pred))
  }

  ################################################################################
  else if(method_ == "BGLM"){#Boosted Generalized Linear Model
    
    frm <- as.formula(paste0(names(train_)[ncol(train_)], "~."))
    
    output <- train_[,ncol(train_)]
    test_ <- test_[,-ncol(test_)]
    
    model <- glmboost(frm, train_)
    pred <- predict(model, test_)
    
    return(as.numeric(pred))
  }
  
  ################################################################################
  else if(method_ == "BRNN"){#Bayesian Regularized Neural Networks
    
    frm <- as.formula(paste0(names(train_)[ncol(train_)], "~."))
    
    output <- train_[,ncol(train_)]
    test_ <- test_[,-ncol(test_)]
    
    model <- brnn(frm, train_, verbose = FALSE)
    pred <- predict(model, test_)
    
    return(as.numeric(pred))
  }
  
  ################################################################################
  else if(method_ == "Cubist"){#Cubist
    
    output <- train_[,ncol(train_)]
    train_ <- train_[,-ncol(train_)]
    test_ <- test_[,-ncol(test_)]
    
    model <- cubist(train_, output)
    pred <- predict(model, test_)
    
    return(as.numeric(pred))
  }
  
  ################################################################################
  else{
    return(NULL)
  }
  
}

