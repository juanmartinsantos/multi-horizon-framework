# Cargar las librerías necesarias
library(ggplot2)
library(sf)
library(mapSpain)
library(viridis)
library(grid)
library(cowplot)
library(dplyr)
library(stringr)

# Lista de provincias a resaltar con nombres actualizados
provincias_actualizadas <- c(
  "Albacete",
  "Almería",
  "Asturias",
  "Badajoz",
  "Burgos",
  "Cáceres",
  "Guadalajara",
  "Huelva",
  "Jaén",
  "La Coruña",
  "Lérida",
  "Lugo",
  "Murcia",
  "Navarra",
  "Salamanca",
  "Sevilla",
  "Teruel",
  "Toledo",
  "Valencia",
  "Zaragoza"
)

# Lista de provincias a resaltar con nombres actualizados
prov_abr <- c(
  "alb",
  "alm",
  "ast",
  "bad",
  "bur",
  "cac",
  "gua",
  "hue",
  "jae",
  "lac",
  "ler",
  "lug",
  "mur",
  "nav",
  "sal",
  "sev",
  "ter",
  "tol",
  "val",
  "zar"
)

# Obtener las provincias como objeto espacial
provincias_sf <- esp_get_prov()

# Obtener las provincias a resaltar como objeto espacial utilizando los nombres actualizados
provincias_resaltar <- esp_get_prov(prov = provincias_actualizadas)

# Crear un índice manual utilizando los nombres actualizados
provincias_resaltar$indice <- match(provincias_resaltar$prov.shortname.es, provincias_actualizadas)

# Calcular los centroides
provincias_resaltar$centroid <- st_centroid(provincias_resaltar$geometry)

# Extraer coordenadas de los centroides
centroid_coords <- st_coordinates(provincias_resaltar$centroid)
provincias_resaltar$lon <- centroid_coords[, 1]
provincias_resaltar$lat <- centroid_coords[, 2]

# Asignar colores a las provincias
colores_fondo <- viridis::viridis(20, option = "turbo")

# Asignar colores correctos según el índice
provincias_resaltar$indice_factor <- factor(provincias_resaltar$indice, levels = 1:20)
colores_fondo_named <- setNames(colores_fondo, levels(provincias_resaltar$indice_factor))

# Gráfico del mapa
mapa <- ggplot() +
  geom_sf(data = provincias_sf, fill = NA, color = "gray") +
  geom_sf(data = provincias_resaltar, aes(fill = indice_factor), color = "black", alpha = 0.6) +
  geom_sf(data = esp_get_can_box()) +
  geom_label(data = provincias_resaltar, aes(x = lon, y = lat, label = indice), size = 4, color = "white", fill = "navy", label.size = 0.5) +
  scale_fill_manual(values = colores_fondo_named) +
  theme_linedraw() +
  theme(legend.position = "none")

# Leyenda
leyenda_df <- provincias_resaltar %>%
  arrange(indice) %>%
  mutate(
    leyenda_texto = paste0(indice, " - ", prov.shortname.es, " (", prov_abr, ")"),
    colores = colores_fondo_named[as.character(indice)]
  )

# Crear el fondo para toda la leyenda como un gran rectángulo
fondo_leyenda <- annotation_custom(
  grob = rectGrob(gp = gpar(fill = "white", col = "black", lwd = 1)),  # Fondo blanco y borde negro
  xmin = -0.01, xmax = 0.048, ymin = -Inf, ymax = Inf  # Abarca toda la leyenda
)

# Leyenda
leyenda <- ggplot(leyenda_df) +
  fondo_leyenda +  # Añadir el fondo detrás de toda la leyenda
  # Etiquetas de texto sin recuadro
  geom_text(
    aes(
      x = 0,
      y = rev(indice),
      label = leyenda_texto  # Etiqueta con "número - nombre"
    ),
    size = 3.5,             # Tamaño del texto
    color = "black",        # Texto negro
    hjust = 0,
    fontface = "bold"       # Texto en negrita
  ) +
  scale_fill_identity() +    # Usa los colores sin una escala adicional
  theme_void() +             # Quitar el fondo de la gráfica
  theme(
    plot.margin = margin(5, 10, 5, 5)
  )

# Combinar mapa y leyenda, dando más espacio a la leyenda
plot_final <- plot_grid(
  mapa,
  leyenda,
  ncol = 2,
  rel_widths = c(4.5, 1.5)  # Aumentar el ancho de la leyenda
)

# Mostrar el gráfico final
print(plot_final)
