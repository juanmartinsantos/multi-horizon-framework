###############################################################################
###############################################################################
###############################################################################
user <- Sys.getenv("USERNAME")
path <- paste0("C:/Users/",user,"/OneDrive/Doctorado/temp_TS/Nueva_revision/Temp_TS_JM/")

# Load library
source(paste0(path, "02.code/project_library.R"))
# setwd("~/research/software/Rcode/24_ts/")

# Load other scripts
scripts <- c('00_functions.R','00_regression_models.R')
files <- list.files(path = paste0(path,"/02.code/"), pattern = "[.]R$", recursive = TRUE)
files <- files[files%in%scripts]
lapply(paste0(path,"02.code/", files), source)

###############################################################################
# -------------------------- Crea tablas HISTORICA -------------------------- #
###############################################################################
files <- list.files(paste0(path, "01.data/newdata/"))

# Crear un dataframe vacío para almacenar los resultados
# Columnas: Dataset, Region, Tmax, Tmin, T
result_df <- as.data.frame(matrix(NA, nrow = length(files), ncol = 6), stringsAsFactors = FALSE)
colnames(result_df) <- c("Index", "Dataset", "Region", "Tmax", "Tmin", "T")

# Iterar sobre los archivos y calcular las estadísticas
for(f in 1:length(files)) {
  file <- files[f]
  # Cargar el dataset
  data <- read.table(file = paste0(path, "01.data/newdata/", file), header = TRUE, sep = ";")
  
  # Extraer el nombre del archivo sin la extensión para Dataset
  dataset_name <- tools::file_path_sans_ext(basename(file))
  
  # Supongamos que la columna "Region" se puede obtener de alguna forma del archivo o su nombre
  region <- "Provincia"  # Aquí puedes modificar si tienes una columna para la región en tu dataset
  
  # Calcular medias y desviaciones estándar, formateando con sprintf para 2 decimales
  t_mean_sd <- sprintf("%.2f ± %.2f", mean(data$output, na.rm = TRUE), sd(data$output, na.rm = TRUE))
  tmin_mean_sd <- sprintf("%.2f ± %.2f", mean(data$tmin, na.rm = TRUE), sd(data$tmin, na.rm = TRUE))
  tmax_mean_sd <- sprintf("%.2f ± %.2f", mean(data$tmax, na.rm = TRUE), sd(data$tmax, na.rm = TRUE))
  
  # Rellenar la fila correspondiente en el dataframe resultante
  result_df[f, ] <- c(f, dataset_name, region, tmax_mean_sd, tmin_mean_sd, t_mean_sd)
}

# Imprimir la tabla resultante
print(result_df)

################################################################################
################################################################################
################################################################################
result_df$Region <- c(
  "A Coruña",
  "Albacete",
  "Almería",
  "Asturias",
  "Badajoz",
  "Burgos",
  "Cáceres",
  "Guadalajara",
  "Huelva",
  "Jaén",
  "Lleida",
  "Lugo",
  "Murcia",
  "Navarra",
  "Salamanca",
  "Sevilla",
  "Teruel",
  "Toledo",
  "Valencia",
  "Zaragoza"
)

result_df$Dataset <- c(
  "aco",  # A Coruña
  "alb",  # Albacete
  "alm",  # Almería
  "ast",  # Asturias
  "bad",  # Badajoz
  "bur",  # Burgos
  "cac",  # Cáceres
  "gua",  # Guadalajara
  "hue",  # Huelva
  "jae",  # Jaén
  "lle",  # Lleida
  "lug",  # Lugo
  "mur",  # Murcia
  "nav",  # Navarra
  "sal",  # Salamanca
  "sev",  # Sevilla
  "ter",  # Teruel
  "tol",  # Toledo
  "val",  # Valencia
  "zar"   # Zaragoza
)

################################################################################
################################################################################
################################################################################
# Guardar la tabla en un archivo CSV si es necesario
write.xlsx(result_df, file = paste0(path, "05.other/tabla_1_paper.xlsx"))

