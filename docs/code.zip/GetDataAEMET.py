
import requests, urllib, json
from time import sleep
import pandas as pd

#%%
# Parametros
fechaini = "2008-01-01"
fechafin = "2008-01-10"
estacion = "5270B"
api_key = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJqdWFubWFydGluQHVzYWwuZXMiLCJqdGkiOiJmZWJhZGYzZS04ZWNmLTRmODQtOWM1Ny00YzA4ZGE5OWQ1ODAiLCJpc3MiOiJBRU1FVCIsImlhdCI6MTcxNTI1NTY0NywidXNlcklkIjoiZmViYWRmM2UtOGVjZi00Zjg0LTljNTctNGMwOGRhOTlkNTgwIiwicm9sZSI6IiJ9.IHpbfLtt-xBe-3xakdK66elzbH8ADyGIPyxgQoiHwjo"

#%%
url = f"https://opendata.aemet.es/opendata/api/valores/climatologicos/diarios/datos/fechaini/{fechaini}T00:00:00UTC/fechafin/{fechafin}T23:59:59UTC/estacion/{estacion}/?api_key={api_key}"
headers = {
    'cache-control': "no-cache"
    }

response = requests.request("GET", url, headers=headers)
print(response.json()["estado"])

if response.json()["estado"] == 200:
    url_datos = response.json()["datos"]

del response
#%%
# Extrae los datos
response = urllib.request.urlopen(url_datos)
sleep(3)

df_json = response.read()

try:
    data = json.loads(df_json)
except UnicodeDecodeError:
    data_bytes = df_json.decode('iso-8859-1')
    data = json.loads(data_bytes)

df = pd.DataFrame(data)

#%%
# Formate los datos
df = df.reset_index(drop = True)
# Reemplazo "," por "."
atts = ['fecha', 'indicativo', 'nombre', 'provincia', 'altitud', 'tmed', 'tmin', 'tmax']

data = df[atts]
columns_to_replace = ['tmed', 'tmin', 'tmax']
for columna in columns_to_replace:
    # columna = columns_to_replace[0]
    data[columna] = data[columna].str.replace(",", ".").astype(float)


# df_final = pd.concat(df_final, data)


#%%
# data.to_csv(path + '01.data/raw/data.csv', sep = ";", index = False)