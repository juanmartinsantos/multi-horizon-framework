
import os
import pandas as pd

#%%
path = "C:/Users/JuanMiguelMartinSant/OneDrive/Doctorado/temp_TS/Nueva_revision/Temp_TS_JM/"
files = os.listdir(path + '01.data/raw/')

features = ['IdProvincia','IdEstacion','Fecha','Año','Dia','Temp Media (ºC)',
            'Temp Max (ºC)','Temp Mínima (ºC)','Humedad Media (%)',
            'Humedad Max (%)','Humedad Min (%)','Velviento (m/s)',
            'VelVientoMax (m/s)','Precipitación (mm)']

meteo = pd.DataFrame()
for file in files:
    # file = files[0]
    filepath = path + '01.data/raw/' + file
    df = pd.read_csv(filepath, encoding='utf-16-le', sep=";")
    df = df[features]
    
    df = df.rename(columns = {'IdProvincia':'IdProvincia',
                              'IdEstacion':'IdEstacion',
                              'Fecha':'Date',
                              'Año':'YEAR',
                              'Dia':'DAY',
                              'Temp Media (ºC)':'TEMPERATURE',
                              'Temp Max (ºC)':'TEMPERATURE_MAX',
                              'Temp Mínima (ºC)':'TEMPERATURE_MIN',
                              'Humedad Media (%)':'HUMIDITY',
                              'Humedad Max (%)':'HUMIDITY_MAX',
                              'Humedad Min (%)':'HUMIDITY_MIN',
                              'Velviento (m/s)':'WIND_SPEED',
                              'VelVientoMax (m/s)':'WIND_SPEED_MAX',
                              'Precipitación (mm)':'PLUVIOMETER'})
    
    meteo = pd.concat([meteo, df], 0)

#%%
meteo = meteo.reset_index(drop = True)
# Reemplazo "," por "."
columns_to_replace = ["TEMPERATURE", "TEMPERATURE_MAX", "TEMPERATURE_MIN",
                      "HUMIDITY", "HUMIDITY_MAX", "HUMIDITY_MIN",
                      "WIND_SPEED", "WIND_SPEED_MAX", "PLUVIOMETER"]

for columna in columns_to_replace:
    # columna = columns_to_replace[0]
    meteo[columna] = meteo[columna].str.replace(",", ".").astype(float)

#%%

meteo.to_csv(path + '01.data/raw/joined.csv', sep = ";", index = False)
