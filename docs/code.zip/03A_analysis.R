###############################################################################
###############################################################################
###############################################################################
user <- Sys.getenv("USERNAME")
path <- paste0("C:/Users/",user,"/OneDrive/Doctorado/temp_TS/Nueva_revision/Temp_TS_JM/")

source(paste0(path, "02.code/project_library.R"))
source(paste0(path, "02.code/00_functions.R"))

###############################################################################
###############################################################################
###############################################################################
max_horizon <- 31

# files <- list.files(paste0(path, "04.results/Gain"))
# cdad <- files[11] # "ALBACETE" alm, pon

file <- paste0(path, "04.results/GAIN_media_resultados.csv") # Utiliza las medias de todos los datasets
# file <- paste0(path, "04.results/Gain/",cdad)
res <- read.table(file = file, header = T, sep = ";")
res[is.na(res)] <- 0
rownames(res) <- res[,1]
res$Feature <- NULL
res <- t(res)

res_r <- 1:93
res_c <- c(96,95,97,94)
res_h <- 98:172

res_x <- list(res_r, res_h, res_c)

####################################################################################
####################################################################################
####################################################################################

# Table 2 "paper"

ultres <- NULL

### 1) all: recent, historical, calendar
dp_ori <- res
uq_type <- c("Recent", "Historical", "Calendar")
var_type <- rep("NA", ncol(dp_ori))
var_type[res_r] <- "Recent"
var_type[res_h] <- "Historical"
var_type[res_c] <- "Calendar"
dp_ori <- f1()
ultres <- rbind(ultres, f2()) 

# write.table(x = ultres, file = paste0(path, "04.results/res_paper/tablas_2/imp_type_",cdad), quote = F, sep = ";", row.names = T, col.names = T)
write.table(x = ultres, file = paste0(path, "04.results/res_paper/tabla2_imp_type_mdres.csv"), quote = F, sep = ";", row.names = T, col.names = T)

####################################################################################
####################################################################################
####################################################################################

# Figura 2 "paper"

dp_ori <- res
uq_type <- c("Recent", "Historical", "Calendar")
var_type <- rep("NA", ncol(dp_ori))
var_type[res_r] <- "Recent"
var_type[res_h] <- "Historical"
var_type[res_c] <- "Calendar"
pct_mean <- f1()

x <- 1:max_horizon
y <- as.vector(pct_mean)
Type <- rep(colnames(pct_mean), each = max_horizon)
Type <- factor(Type, levels=colnames(pct_mean))
dp_ggp <- data.frame(x = x, y = y, Type = Type)

ggp <-  ggplot(dp_ggp, aes(x, y, col = Type, linetype = Type)) +
  geom_line(linewidth = 1.5) +
  scale_x_continuous(breaks = 1:31) +
  scale_y_continuous(breaks = seq(0,0.015,0.001)) +
  xlab("Time horizon (days)") +
  ylab("Importance") +
  theme(axis.text = element_text(size = 18), axis.title = element_text(size = 26, face="bold"),
        legend.text = element_text(size = 20), legend.title = element_text(size = 24, face="bold"),
        legend.key.size = unit(2.5,"line"), legend.box.background=element_rect(),
        legend.box.margin=margin(5,5,5,5), plot.margin = margin(0.4,0.4,0.4,0.4, "cm"))
ggp$labels$colour <- "Variable type"
ggp$labels$linetype <- "Variable type"
# ggp

# ggsave(paste0(path, "04.results/res_paper/figuras_2/plot_f1",sub("\\.csv$", "", cdad), ".png"), plot = ggp, width = 18, height = 10)
ggsave(paste0(path, "04.results/res_paper/figura2_mdres.png"), plot = ggp, width = 18, height = 10)
# Como pdf 6.5 x 14
####################################################################################
####################################################################################
####################################################################################

# Table 3 "paper"

ultres <- NULL

### 1) recent: t, tmin, tmax
dp_ori <- res[,res_r]
uq_type <- c("t", "tmin", "tmax")
var_type <- rep(c("t", "tmin", "tmax"), each = 31)
dp_ori <- f1()
ultres <- rbind(ultres, f2())

### 2) recent: w1, w2, w3, w4
dp_ori <- res[,res_r]
uq_type <- c("w1", "w2", "w3", "w4")
var_type <- c(rep(uq_type, each = 7), c("w4","w4","w4"))
var_type <- rep(var_type, 3)
dp_ori <- f1()
ultres <- rbind(ultres, f2())

### 3) historical: t, tmin, tmax
dp_ori <- res[,res_h]
vars <- colnames(dp_ori)
uq_type <- c("t", "tmin", "tmax")
var_type <- rep(c("t", "tmin", "tmax"), length(vars)/3)
dp_ori <- f1()
ultres <- rbind(ultres, f2())

### 4) historical: year 1,2,3,4,5
dp_ori <- res[,res_h]
vars <- colnames(dp_ori)
uq_type <- c(1,2,3,4,5)
var_type <- rep(c(1,2,3,4,5), each = length(vars)/5)
dp_ori <- f1()
ultres <- rbind(ultres, f2())

### 5) historical: day 1,3,7,15,31
dp_ori <- res[,res_h]
vars <- colnames(dp_ori)
uq_type <- c(1,3,7,15,31)
vd <- rep(c(1,3,7,15,31), each = 3)
var_type <- rep(vd, length(vars)/length(vd))
dp_ori <- f1()
ultres <- rbind(ultres, f2())

### 6) calendar
dp_ori <- res[,res_c]
ultres <- rbind(ultres, f2())

# write.table(x = ultres, file = paste0(path, "04.results/res_paper/tablas_3/imp_each_",cdad), quote = F, sep = ";", row.names = T, col.names = T)
write.table(x = ultres, file = paste0(path, "04.results/res_paper/tabla3_imp_each_mdres.csv"), quote = F, sep = ";", row.names = T, col.names = T)

####################################################################################
####################################################################################
####################################################################################

# Figure 3 "paper"

minvt <- c(1/ncol(res),1/ncol(res),0)
txtgr <- c("Recent", "Historical", "Calendar")
limvt <- list(c(0, max(res[,res_x[[1]]])), c(0, max(res[,res_x[[2]]])), c(0, max(res[,res_x[[3]]])))

ncolvt <- rep(NA, 3)
gp <- list()
for(i in 1:3){
  dp_ori <- res[,res_x[[i]]]
  
  # Calcular la importancia promedio por variable
  vars_over_avg <- apply(dp_ori, 2, mean)
  
  # Seleccionar las variables que exceden la importancia promedio en algún día
  if(i == 1){  # Para "Recent" y "Historical", aplicamos el filtro
    top_vars <- order(vars_over_avg, decreasing = TRUE)[1:5]
    dp_ori <- dp_ori[, top_vars]
  }
  if(i == 2){  # Para "Recent" y "Historical", aplicamos el filtro
    top_vars <- order(vars_over_avg, decreasing = TRUE)[1:15]
    dp_ori <- dp_ori[, top_vars]
  }
  
  mxcol <- apply(X = dp_ori, MARGIN = 2, FUN = max)
  dp_ori <- dp_ori[,mxcol >= minvt[i]]
  ncolvt[i] <- ncol(dp_ori)

  x <- as.factor(1:max_horizon)
  x <- factor(x, levels=as.character(1:31))
  y <- rep(colnames(dp_ori), each = max_horizon)
  y <- factor(y, levels=colnames(dp_ori))
  imp <- as.vector(dp_ori)
  dp_ggp <- data.frame(x = x, y = y, Importance = imp)
  
  # Ajusta escala en leyenda 
  lim <- ifelse(i == 1, round(max(limvt[[i]]), 1), round(max(limvt[[i]]), 3))
  
  gp[[i]] <- ggplot(dp_ggp, aes(x, y, fill = Importance)) +
    geom_tile() +
    scale_fill_gradient(low="cornsilk", high="black", limits=c(0, lim)) +
    xlab("Time horizon (days)") +
    ylab(txtgr[i]) +
    theme(axis.text = element_text(size = 18), axis.title = element_text(size = 26, face="bold"),
          legend.text = element_text(size = 16), legend.title = element_text(size = 16, face="bold"),
          legend.key.size = unit(1.2,"line"), legend.box.background=element_rect(),
          legend.box.margin=margin(2,2,10,2), plot.margin = margin(0,0,0,0, "cm"))
}

gp[[1]] <- gp[[1]] + theme(axis.title.x=element_blank())
gp[[2]] <- gp[[2]] + theme(axis.title.x=element_blank())

h <- 0.6
p1 <- egg::set_panel_size(gp[[1]], height=unit(ncolvt[1]*h, "cm"), width=unit(29, "cm"))
p2 <- egg::set_panel_size( gp[[2]], height=unit(ncolvt[2]*h, "cm"), width=unit(29, "cm"))
p3 <- egg::set_panel_size( gp[[3]], height=unit(ncolvt[3]*h, "cm"), width=unit(29, "cm"))
ggp <- cowplot::plot_grid(p1, p2, p3, nrow=3, align = "v", rel_heights = c(1, 0.9, 1))
ggp

# ggsave(paste0(path, "04.results/res_paper/figuras_3/plot_f3",sub("\\.csv$", "", cdad), ".png"), plot = ggp, width = 26, height = 12)
ggsave(paste0(path, "04.results/res_paper/figura3_mdres.png"), plot = ggp, width = 26, height = 12)

# Como pdf 9 x 22
####################################################################################
####################################################################################
####################################################################################

# Figure 4 "paper"

dp_ori <- res
nm <- c()
for(i in 1:nrow(dp_ori)){
  nm <- c(nm, colnames(dp_ori)[order(dp_ori[i,], decreasing = T)[1:5]])
}
nm <- unique(nm)

idm <- match(colnames(dp_ori), nm)
idm <- idm[!is.na(idm)]
nm <- nm[idm]

dp_ori <- dp_ori[,nm]

x <- 1:max_horizon
y <- as.vector(dp_ori)
Variable <- rep(colnames(dp_ori), each = max_horizon)
Variable <- factor(Variable, levels=colnames(dp_ori))
dp_ggp <- data.frame(x = x, y = y, Variable = Variable)

ggp <- ggplot(dp_ggp, aes(x, y, col = Variable, linetype = Variable)) +
  geom_line(size = 1) +
  scale_x_continuous(breaks = 1:31) +
  scale_y_log10(breaks = c(0.001, 0.01, 0.1, 1), labels = scales::trans_format("log10", scales::math_format(10^.x))) +  # Escala logarítmica en el eje y
  xlab("Time horizon (days)") +
  ylab("Importance") +
  theme(axis.text = element_text(size = 20), axis.title = element_text(size = 26, face="bold"),
        legend.text = element_text(size = 20), legend.title = element_text(size = 24, face="bold"),
        legend.key.size = unit(2.5,"line"), legend.box.background=element_rect(),
        legend.box.margin=margin(5,5,5,5), plot.margin = margin(0.4,0.4,0.4,0.4, "cm"))


# --- Sin escalado logaritmico --- #
# ggp <-  ggplot(dp_ggp, aes(x, y, col = Variable, linetype = Variable)) +
#   geom_line(size = 1) +
#   scale_x_continuous(breaks = 1:31) +
#   scale_y_continuous(breaks = seq(0,0.9,0.1)) +
#   xlab("Time horizon (days)") +
#   ylab("Importance") +
#   theme(axis.text = element_text(size = 20), axis.title = element_text(size = 26, face="bold"),
#         legend.text = element_text(size = 20), legend.title = element_text(size = 24, face="bold"),
#         legend.key.size = unit(2.5,"line"), legend.box.background=element_rect(),
#         legend.box.margin=margin(5,5,5,5), plot.margin = margin(0.4,0.4,0.4,0.4, "cm"))


ggp
# ggsave(paste0(path, "04.results/res_paper/figuras_4/plot_f4",sub("\\.csv$", "", cdad), ".png"), plot = ggp, width = 26, height = 12)
# ggsave(paste0(path, "04.results/res_paper/figura4_mdres.png"), plot = ggp, width = 26, height = 12)
# Como PDF 8 * 15
####################################################################################
####################################################################################
####################################################################################
rm(list = ls())
