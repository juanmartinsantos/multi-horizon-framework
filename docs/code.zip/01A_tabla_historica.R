###############################################################################
###############################################################################
###############################################################################
user <- Sys.getenv("USERNAME")
path <- paste0("C:/Users/",user,"/OneDrive/Doctorado/temp_TS/Nueva_revision/Temp_TS_JM/")

# Load library
source(paste0(path, "02.code/project_library.R"))
# setwd("~/research/software/Rcode/24_ts/")

# Load other scripts
scripts <- c('00_functions.R','00_regression_models.R')
files <- list.files(path = paste0(path,"/02.code/"), pattern = "[.]R$", recursive = TRUE)
files <- files[files%in%scripts]
lapply(paste0(path,"02.code/", files), source)

###############################################################################
# -------------------------- Crea tablas HISTORICA -------------------------- #
###############################################################################
files <- list.files(paste0(path, "01.data/newdata/"))

for(file in files){
  data <- read.table(file = paste0(path, "01.data/newdata/", file), header = T, sep = ";")
  data$date <- as.Date(x = as.character(data$date), format = "%Y-%m-%d")
  data$t <- data$output
  data <- data[,c("t", "tmin", "tmax", "date", "yearday", "month", "day", "year","output")]
  
  # Create historical data
  dh5 <- HISTdata(data, 5)
  # send_telegram()
  
  write.table(x = dh5, file = paste0(path, "01.data/dh5_newdata/dh5_",file), sep = ";", row.names = F, col.names = T)
}

##############
# CHECK DAYS #
##############
# data222 <- read.table(file = paste0(path, "01.data/dh5/dh5_",cdad,".csv"), header = T, sep = ";")
# for(i in 1:ncol(data222)){
#   print(is.numeric(data222[,i]))
# }
# 
# date_range <- seq(min(data$date), max(data$date), by = 1) 
# md <- date_range[!date_range %in% data$date] 
# 
# length(md)
# 
# table(year(md))

